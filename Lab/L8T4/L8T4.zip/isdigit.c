_Bool isDigitChar(char c) {
    if (c >= 48 && c <= 57) return 1;
    return 0;
}
