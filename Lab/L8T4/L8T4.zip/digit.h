_Bool isDigitChar(char c);
/* _Bool isDigitChar(char c) {
 *    if ((c >= 'A' && c <= 'Z') && (c >= 'a' && c <= 'z')) return 0;
 *    else return 1;
 * }
*/
